(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[763],{7427:function(e,t,s){(window.__NEXT_P=window.__NEXT_P||[]).push(["/admin/dashboard/feedback",function(){return s(6305)}])},3554:function(e,t,s){"use strict";var r=s(5893),a=s(682),i=s(6819),o=s(4688),n=s(3299),l=s(5005),d=s(979),c=s(8193);t.Z=function(){var e;let{data:t}=(0,n.useSession)(),{collapseSidebar:s}=(0,d.Wf)();return(0,r.jsx)("div",{children:(0,r.jsxs)(o.Z,{collapseOnSelect:!0,expand:"lg",bg:"dark",variant:"dark",children:[(0,r.jsx)("span",{onClick:()=>s(),children:(0,r.jsx)(c.LHV,{size:40,color:"White",className:"mx-3"})}),(0,r.jsxs)(a.Z,{children:[(0,r.jsx)(o.Z.Brand,{href:"#home",children:"GoodVibes Education Consultancy"}),(0,r.jsx)(o.Z.Toggle,{"aria-controls":"responsive-navbar-nav"}),(0,r.jsxs)(o.Z.Collapse,{id:"responsive-navbar-nav",children:[(0,r.jsx)(i.Z,{className:"me-auto",children:(0,r.jsxs)("div",{style:{textAlign:"center",width:"40%",margin:"auto",color:"white"},children:[(0,r.jsx)("span",{style:{color:"white"},children:"Welcome"}),(0,r.jsx)("h5",{style:{color:"red"},className:"my-auto",children:null==t?void 0:null===(e=t.user)||void 0===e?void 0:e.email})]})}),(0,r.jsx)(i.Z,{children:(0,r.jsx)(l.Z,{variant:"danger",onClick:()=>{(0,n.signOut)({redirect:!0,callbackUrl:"/"})},children:"Logout"})})]})]})]})})}},5160:function(e,t,s){"use strict";var r=s(5893);s(5675),s(7294);var a=s(979),i=s(1664),o=s.n(i);let n=()=>(0,r.jsxs)(a.YE,{style:{height:"100vh"},children:[(0,r.jsx)("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",flexDirection:"column"},children:(0,r.jsx)("h5",{className:"text-center p-4",children:"Dashboard"})}),(0,r.jsxs)(a.v2,{children:[(0,r.jsxs)(a.Wd,{label:"UserData",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/user/add",children:[" ","Add User"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/user",children:[" ","All"," "]})]}),(0,r.jsxs)(a.Wd,{label:"AboutData",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/about/add",children:[" ","Add About"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/about",children:[" ","All"," "]})]}),(0,r.jsxs)(a.Wd,{label:"Carousel",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/carousel/add",children:[" ","Add Carousel"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/carousel",children:[" ","All"," "]})]}),(0,r.jsxs)(a.Wd,{label:"SuccessStory",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/successstory/add",children:[" ","Add SuccessStory"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/successstory",children:[" ","All"," "]})]}),(0,r.jsxs)(a.Wd,{label:"Faq",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/faq/add",children:[" ","Add Faq"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/faq",children:[" ","All"," "]})]}),(0,r.jsxs)(a.Wd,{label:"Blog",children:[(0,r.jsxs)(a.sN,{as:o(),href:"/admin/dashboard/blog/add",children:[" ","Add Blog"," "]}),(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/blog",children:[" ","All"," "]})]}),(0,r.jsx)(a.Wd,{label:"FeedbackData",children:(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/feedback",children:[" ","All"," "]})}),(0,r.jsx)(a.Wd,{label:"FormData",children:(0,r.jsxs)(a.sN,{ad:o(),href:"/admin/dashboard/form",children:[" ","All"," "]})})]})]});t.Z=n},5845:function(e,t,s){"use strict";var r=s(5893);s(7294);var a=s(9109);let i=()=>(0,r.jsx)(r.Fragment,{children:(0,r.jsx)("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",width:"40%",margin:"auto"},children:(0,r.jsx)(a.VL,{visible:!0,height:"80",width:"80",ariaLabel:"vortex-loading",wrapperStyle:{},wrapperClass:"vortex-wrapper",colors:["red","green","blue","yellow","orange","purple"]})})});t.Z=i},6305:function(e,t,s){"use strict";s.r(t);var r=s(5893),a=s(5160),i=s(3798),o=s(5147),n=s(8193),l=s(7294),d=s(1664),c=s.n(d),u=s(5845),p=s(6501),h=s(1163),f=s(6879),m=s(3554);let x=()=>{var e;let{data:t,isLoading:s}=(0,f.uX)(),a=(0,h.useRouter)(),[i,{isSuccess:d,isError:m}]=(0,f.EJ)();return(0,l.useEffect)(()=>{d&&(p.Am.success("Deleted Successfully"),a.push("/admin/dashboard/feedback"))},[d,p.Am]),console.log(t),(0,r.jsx)(r.Fragment,{children:s?(0,r.jsx)(u.Z,{}):(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(p.x7,{}),(0,r.jsxs)("div",{style:{width:"100%"},children:[(0,r.jsx)("h5",{style:{textAlign:"center"},children:"All Feedback Data List "}),(0,r.jsxs)(o.Z,{responsive:!0,striped:!0,children:[console.log(t),(0,r.jsx)("thead",{children:(0,r.jsxs)("tr",{children:[(0,r.jsx)("th",{children:"Id"}),(0,r.jsx)("th",{children:"FullName"}),(0,r.jsx)("th",{style:{minWidth:"10rem"},children:"message"}),(0,r.jsx)("th",{children:"Image Url"}),(0,r.jsx)("th",{children:"Actions"})]})}),(0,r.jsx)("tbody",{children:null==t?void 0:null===(e=t.feedback)||void 0===e?void 0:e.map((e,t)=>{var s;return(0,r.jsxs)("tr",{children:[(0,r.jsx)("td",{children:e._id}),(0,r.jsx)("td",{children:e.fullname}),(0,r.jsx)("td",{children:e.message}),(0,r.jsx)("td",{children:null===(s=e.images)||void 0===s?void 0:s.url}),(0,r.jsx)("td",{children:(0,r.jsxs)("div",{style:{display:"flex",padding:"1rem",gap:"0.5rem"},children:[(0,r.jsx)(c(),{href:"/admin/dashboard/feedback/".concat(null==e?void 0:e._id),style:{textDecoration:"none"},children:(0,r.jsxs)("span",{children:[(0,r.jsx)(n.QML,{color:""}),"Edit"]})}),(0,r.jsxs)(c(),{href:"/",style:{textDecoration:"none",color:"red"},onClick:t=>{t.preventDefault(),i(null==e?void 0:e._id)},children:[" ",(0,r.jsx)(n.YK6,{}),"Delete"]})]})})]},t)})})]})]})]})})};t.default=x,x.getLayout=function(e){return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(i.C,{children:[(0,r.jsx)(m.Z,{}),(0,r.jsxs)("div",{style:{display:"flex"},children:[(0,r.jsx)(a.Z,{}),e]})]})})}},5147:function(e,t,s){"use strict";var r=s(4184),a=s.n(r),i=s(7294),o=s(6792),n=s(5893);let l=i.forwardRef(({bsPrefix:e,className:t,striped:s,bordered:r,borderless:i,hover:l,size:d,variant:c,responsive:u,...p},h)=>{let f=(0,o.vE)(e,"table"),m=a()(t,f,c&&`${f}-${c}`,d&&`${f}-${d}`,s&&`${f}-${"string"==typeof s?`striped-${s}`:"striped"}`,r&&`${f}-bordered`,i&&`${f}-borderless`,l&&`${f}-hover`),x=(0,n.jsx)("table",{...p,className:m,ref:h});if(u){let e=`${f}-responsive`;return"string"==typeof u&&(e=`${e}-${u}`),(0,n.jsx)("div",{className:e,children:x})}return x});t.Z=l},6501:function(e,t,s){"use strict";let r,a;s.d(t,{x7:function(){return ea},Am:function(){return L}});var i,o=s(7294);let n={data:""},l=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||n,d=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,c=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let s="",r="",a="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+o+";":r+="f"==i[1]?p(o,i):i+"{"+p(o,"k"==i[1]?"":t)+"}":"object"==typeof o?r+=p(o,t?t.replace(/([^,])+/g,e=>i.replace(/(^:.*)|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=p.p?p.p(i,o):i+":"+o+";")}return s+(t&&a?t+"{"+a+"}":a)+r},h={},f=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+f(e[s]);return t}return e},m=(e,t,s,r,a)=>{var i,o;let n=f(e),l=h[n]||(h[n]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(n));if(!h[l]){let t=n!==e?e:(e=>{let t,s,r=[{}];for(;t=d.exec(e.replace(c,""));)t[4]?r.shift():t[3]?(s=t[3].replace(u," ").trim(),r.unshift(r[0][s]=r[0][s]||{})):r[0][t[1]]=t[2].replace(u," ").trim();return r[0]})(e);h[l]=p(a?{["@keyframes "+l]:t}:t,s?"":"."+l)}let m=s&&h.g?h.g:null;return s&&(h.g=h[l]),i=h[l],o=t,m?o.data=o.data.replace(m,i):-1===o.data.indexOf(i)&&(o.data=r?i+o.data:o.data+i),l},x=(e,t,s)=>e.reduce((e,r,a)=>{let i=t[a];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function b(e){let t=this||{},s=e.call?e(t.p):e;return m(s.unshift?s.raw?x(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,l(t.target),t.g,t.o,t.k)}b.bind({g:1});let g,y,v,j=b.bind({k:1});function w(e,t){let s=this||{};return function(){let r=arguments;function a(i,o){let n=Object.assign({},i),l=n.className||a.className;s.p=Object.assign({theme:y&&y()},n),s.o=/ *go\d+/.test(l),n.className=b.apply(s,r)+(l?" "+l:""),t&&(n.ref=o);let d=e;return e[0]&&(d=n.as||e,delete n.as),v&&d[0]&&v(n),g(d,n)}return t?t(a):a}}var N=e=>"function"==typeof e,E=(e,t)=>N(e)?e(t):e,k=(r=0,()=>(++r).toString()),A=()=>{if(void 0===a&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");a=!e||e.matches}return a},$=new Map,C=e=>{if($.has(e))return;let t=setTimeout(()=>{$.delete(e),F({type:4,toastId:e})},1e3);$.set(e,t)},D=e=>{let t=$.get(e);t&&clearTimeout(t)},_=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&D(t.toast.id),{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return e.toasts.find(e=>e.id===s.id)?_(e,{type:1,toast:s}):_(e,{type:0,toast:s});case 3:let{toastId:r}=t;return r?C(r):e.toasts.forEach(e=>{C(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},O=[],Z={toasts:[],pausedAt:void 0},F=e=>{Z=_(Z,e),O.forEach(e=>{e(Z)})},I={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},S=(e={})=>{let[t,s]=(0,o.useState)(Z);(0,o.useEffect)(()=>(O.push(s),()=>{let e=O.indexOf(s);e>-1&&O.splice(e,1)}),[t]);let r=t.toasts.map(t=>{var s,r;return{...e,...e[t.type],...t,duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||I[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...t,toasts:r}},W=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||k()}),z=e=>(t,s)=>{let r=W(t,e,s);return F({type:2,toast:r}),r.id},L=(e,t)=>z("blank")(e,t);L.error=z("error"),L.success=z("success"),L.loading=z("loading"),L.custom=z("custom"),L.dismiss=e=>{F({type:3,toastId:e})},L.remove=e=>F({type:4,toastId:e}),L.promise=(e,t,s)=>{let r=L.loading(t.loading,{...s,...null==s?void 0:s.loading});return e.then(e=>(L.success(E(t.success,e),{id:r,...s,...null==s?void 0:s.success}),e)).catch(e=>{L.error(E(t.error,e),{id:r,...s,...null==s?void 0:s.error})}),e};var P=(e,t)=>{F({type:1,toast:{id:e,height:t}})},T=()=>{F({type:5,time:Date.now()})},M=e=>{let{toasts:t,pausedAt:s}=S(e);(0,o.useEffect)(()=>{if(s)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let s=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(s<0){t.visible&&L.dismiss(t.id);return}return setTimeout(()=>L.dismiss(t.id),s)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,s]);let r=(0,o.useCallback)(()=>{s&&F({type:6,time:Date.now()})},[s]),a=(0,o.useCallback)((e,s)=>{let{reverseOrder:r=!1,gutter:a=8,defaultPosition:i}=s||{},o=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+a,0)},[t]);return{toasts:t,handlers:{updateHeight:P,startPause:T,endPause:r,calculateOffset:a}}},H=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${j`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${j`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${j`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,U=w("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${j`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,q=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${j`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${j`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,B=w("div")`
  position: absolute;
`,R=w("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=w("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${j`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,X=({toast:e})=>{let{icon:t,type:s,iconTheme:r}=e;return void 0!==t?"string"==typeof t?o.createElement(V,null,t):t:"blank"===s?null:o.createElement(R,null,o.createElement(U,{...r}),"loading"!==s&&o.createElement(B,null,"error"===s?o.createElement(H,{...r}):o.createElement(q,{...r})))},Y=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,G=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,J=w("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,K=w("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Q=(e,t)=>{let s=e.includes("top")?1:-1,[r,a]=A()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[Y(s),G(s)];return{animation:t?`${j(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${j(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ee=o.memo(({toast:e,position:t,style:s,children:r})=>{let a=e.height?Q(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(X,{toast:e}),n=o.createElement(K,{...e.ariaProps},E(e.message,e));return o.createElement(J,{className:e.className,style:{...a,...s,...e.style}},"function"==typeof r?r({icon:i,message:n}):o.createElement(o.Fragment,null,i,n))});i=o.createElement,p.p=void 0,g=i,y=void 0,v=void 0;var et=({id:e,className:t,style:s,onHeightUpdate:r,children:a})=>{let i=o.useCallback(t=>{if(t){let s=()=>{r(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return o.createElement("div",{ref:i,className:t,style:s},a)},es=(e,t)=>{let s=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:A()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...r}},er=b`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ea=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:r,children:a,containerStyle:i,containerClassName:n})=>{let{toasts:l,handlers:d}=M(s);return o.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:n,onMouseEnter:d.startPause,onMouseLeave:d.endPause},l.map(s=>{let i=s.position||t,n=es(i,d.calculateOffset(s,{reverseOrder:e,gutter:r,defaultPosition:t}));return o.createElement(et,{id:s.id,key:s.id,onHeightUpdate:d.updateHeight,className:s.visible?er:"",style:n},"custom"===s.type?E(s.message,s):a?a(s):o.createElement(ee,{toast:s,position:i}))}))}}},function(e){e.O(0,[109,774,888,179],function(){return e(e.s=7427)}),_N_E=e.O()}]);